pip3 install Flask --user
pip3 install requests --user
pip3 install validators --user
pip3 install BeautifulSoup4 --user
pip3 install segtok --user
FLASK_APP=server.py flask run -p 5001